/** Automatically generated file. DO NOT MODIFY */
package com.jay.example.downloaddemo1;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}