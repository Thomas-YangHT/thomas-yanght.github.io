package com.jay.example.service;

public interface DownloadProgressListener {

	public void onDownloadSize(int downloadedSize);
}
