package com.jay.example.downloaddemo1;


import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {

	
	
	private Button btnsave;
	private EditText editurl;
	
	Handler handler = new Handler()
	{
		public void handleMessage(android.os.Message msg) 
		{
			if(msg.what == 0x123)
			{
				Toast.makeText(getApplicationContext(), "��ʼ����", Toast.LENGTH_SHORT).show();
			}
		};
	};
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		btnsave = (Button) findViewById(R.id.btnsave);
		editurl = (EditText) findViewById(R.id.editurl);
		
		btnsave.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				new Thread()
				{
					@Override
					public void run() {
						String path = editurl.getText().toString();
						try {
							DownLoadService.downLoad(path, MainActivity.this);
						} catch (Exception e) {e.printStackTrace();}
						handler.sendEmptyMessage(0x123);
					}
				}.start();
				
			}
		});
		
	}
}
