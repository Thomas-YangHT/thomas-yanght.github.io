package com.wwj.net.download;

public interface DownloadProgressListener {
	public void onDownloadSize(int size);
}
